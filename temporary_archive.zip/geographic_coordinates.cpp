//
//  geographic_coordinates.cpp
//  source
//
//  Created by Kwadwo Oteng-Amoko on 09/03/2020.
//  Copyright © 2020 Kwadwo Oteng-Amoko. All rights reserved.
//

#include "geographic_coordinates.hpp"

// methods
// store the data
