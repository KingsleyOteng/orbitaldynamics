//
//  geomagnetic_field_model.hpp
//  source
//
//  Created by Kwadwo Oteng-Amoko on 09/03/2020.
//  Copyright © 2020 Kwadwo Oteng-Amoko. All rights reserved.
//

#ifndef geomagnetic_field_model_hpp
#define geomagnetic_field_model_hpp

#include <stdio.h>

#endif /* geomagnetic_field_model_hpp */
