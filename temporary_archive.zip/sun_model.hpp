//
//  sun_model.hpp
//  source
//
//  Created by Kwadwo Oteng-Amoko on 09/03/2020.
//  Copyright © 2020 Kwadwo Oteng-Amoko. All rights reserved.
//

#ifndef sun_model_hpp
#define sun_model_hpp

#include <stdio.h>

#endif /* sun_model_hpp */
