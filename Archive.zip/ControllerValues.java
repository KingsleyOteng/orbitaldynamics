/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication3;

import java.math.BigDecimal;

/**
 *
 * @author kwadwooteng-amoko
 */
public class ControllerValues {
    
    public ControllerValues(BigDecimal t, BigDecimal tt, BigDecimal ttt)
    {
      
    }
    
    public ControllerValues()
    {
      
    }
}
